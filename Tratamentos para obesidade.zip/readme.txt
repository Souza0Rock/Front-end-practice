Seguir modelo do arquivo home

Requisitos:
Construir o site usando html e css(flexbox);
Tentar ser o mais fiel possivel ao layout;

Observações:
Todos as imagens necessarias para construção do site está na pasta images;
Formulario funcional porém sem disparo;
Fontes e cores ficam a critério de sua observação, tentando ser o mais proximo do layout
Após finalizado mandar para o email: felipepaulino08@hotmail.com, zipado;

Boa sorte;
